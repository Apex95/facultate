package visualiser;

public enum Color {
	RED,  // canvas
	GREEN, // menu
	BLUE, // dialog
	GREY // unknown
	
}
