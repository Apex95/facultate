package visualiser;

import graphics.Renderer;
import io.Parser;
import visualiser.ClusterManager.Cluster;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;

final class Main {
	private static Renderer renderer;

	private static Map<visualiser.Color, java.awt.Color> colorsMap = new HashMap<visualiser.Color, java.awt.Color>()
	{
		{
			put(visualiser.Color.RED, java.awt.Color.RED);
			put(visualiser.Color.BLUE, java.awt.Color.BLUE);
			put(visualiser.Color.GREEN, java.awt.Color.GREEN);
			put(visualiser.Color.GREY, java.awt.Color.GRAY);
		}
	};
	
	
	public static void main(String[] args) {
		List<Task> tasks = readTasks("logs/alfred");

		renderer = Renderer.builder()
				.withColorsMap(colorsMap)
				.withDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
				.withTitle("All data")
				.withSize(1300, 300)
				.build();
		drawAll(tasks);
		renderer.draw();
		
		renderer = Renderer.builder()
				.withColorsMap(colorsMap)
				.withDefaultCloseOperation(JFrame.EXIT_ON_CLOSE)
				.withTitle("Clusters")
				.withSize(1300, 300)
				.build();
		drawClusters(tasks);
		renderer.draw();
	}
	
	private static List<Task> readTasks(String path) {
		
		File[] filesList = new File(path).listFiles();
		List<Task> tasks = new ArrayList<>();
		if (filesList == null) {
			return tasks;
		}
		
		for (File f : filesList)
			try 
			{
				tasks.add(new Task(Parser.readFromFile(f.getPath())));
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		return tasks;
	}
	
	private static void drawAll(List<Task> tasks) {
		for (Task t : tasks)
			for (UserEvent u : t.getUserEvents())
				renderer.addPoint(getXValueFor(u), getYValueFor(u), u.getPageArea().getVisualisationColor());
		
	}
	
	private static void drawClusters(List<Task> tasks) {
		List<UserEvent> userEvents = new ArrayList<UserEvent>();
		
		for (Task t : tasks)
		{
			userEvents.addAll(t.getUserEvents());
			
			for (UserEvent u : t.getUserEvents())
				renderer.addPoint(getXValueFor(u), getYValueFor(u), visualiser.Color.GREY);
		}
		
		ClusterManager clusterManager = ClusterManager.getInstance();
		
		
		List<Cluster> clusters = clusterManager.cluster(userEvents);
		
		int colorsIndex = 0;
		
		for (Cluster c : clusters)
		{
			for (UserEvent u : c.getUserEvents())
				renderer.addPoint(getXValueFor(u), getYValueFor(u), visualiser.Color.values()[colorsIndex %3]);
			
			colorsIndex++;
		}
		
	}
	
	private static int getXValueFor(UserEvent e) {
		return e.getTimestamp()*10+50;
	}
	
	
	Map<EditorElement, Integer> elementCoords = new HashMap<EditorElement, Integer>();
	
	private static int getYValueFor(UserEvent e) {
		if (e.getPageArea() instanceof Canvas)
			return 50;
		
		if (e.getPageArea() instanceof DialogBox)
			return 120;
		
		if (e.getPageArea() instanceof Menu)
			return 190;
		
		return 260;
		
		
	}
}
