package visualiser;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.google.common.annotations.VisibleForTesting;

public final class Task {
	// TODO(2): Adaugati campurile, constructorii necesari si metodele care lipsesc.
	
	private final List<UserEvent> userEvents; 
	
	public Task() {
		userEvents = new ArrayList<>();
	}
	
	public Task(String logs) {
		userEvents = new ArrayList<>();
		parseLogs(logs);
	}
	
	public Double meanFrequencyPerTenSeconds() {
		// TODO(2): Implementati metoda care va calcula frecventa medie pe intervale de 10 secunde.

		double result = 0;
		int intervals = 0; 
		int entries = 0; 
		
		
		for (int i = userEvents.get(0).getTimestamp(); ; i += 10)
		{
			entries = 0;
			
			for (UserEvent u : userEvents)
				if (u.getTimestamp() >= i && u.getTimestamp() <= i + 9)
					entries++;
			
			if (entries == 0)
				break;
			else
			{
				intervals++;
				result += entries / 10.0;
			}
			
		}
		
		return intervals == 0 ? 0 : result / intervals;
	}
	
	public Map<String, Double> computeClicksPerArea() {
		Map<String, Double> clickMap = new HashMap<String, Double>();		
		
		for (UserEvent u : userEvents)
		{
			if (!clickMap.containsKey(u.getPageArea().getClass().getCanonicalName()))
				clickMap.put(u.getPageArea().getClass().getCanonicalName(), 1d);
			else
				clickMap.put(u.getPageArea().getClass().getCanonicalName(), clickMap.get(u.getPageArea().getClass().getCanonicalName()) + 1);
		}
		return clickMap;
	}

	

	@VisibleForTesting
	List<UserEvent> parseLogs(String logs) {
		// R: apelul se face din al 2-lea constructor ce primeste logs ca parametru
		
		userEvents.clear();
		
		// black magic below
		
		Pattern eventPattern = Pattern.compile("user_event\\s*\\{([a-z-A-Z0-9:\\s\\\"_-]+)\\}");
		Matcher matcher = eventPattern.matcher(logs);
		
		while (matcher.find())
		{
			// more black magic :))
			Pattern propertiesPattern = Pattern.compile("([a-zA-Z0-9_-]+)\\s*:\\s\\\"*([a-z-A-Z0-9_-]+)\\\"*");
			Matcher matcher2 = propertiesPattern.matcher(matcher.group());
		
			String token = null;
			String value = null;
		
			int currentTimestamp = 0;
			List<EditorElement> elementsList = new ArrayList<>();

			while (matcher2.find())
			{
				token = matcher2.group(1);
				value = matcher2.group(2);
				
				if (token.equals("element"))
					elementsList.add(new EditorElement(value));
			
				if (token.equals("timestamp"))
					currentTimestamp = Integer.parseInt(value);
			}
			
			userEvents.add(new UserEvent(determineAreaForElements(elementsList), currentTimestamp));
		}
		
		return userEvents;
	}

	
	// factory method
	@VisibleForTesting
	EditorArea determineAreaForElements(List<EditorElement> elements) {
		for (EditorElement e : elements)
		{
			// tratate asa deoarece unele au ghilimele iar altele nu
			
			if (e.getType().contains("card") || e.getType().contains("input") || e.getType().contains("page"))
				return new Canvas(elements);
		
			// tehnic vorbind va include si menu-button
			if (e.getType().contains("menu") || e.getType().contains("icon"))
				return new Menu(elements);
			
			if (e.getType().contains("dialog"))
				return new DialogBox(elements);
		}
		
		return new UnknownArea(elements);
	}
	
	public List<UserEvent> getUserEvents() {
		return userEvents;
	}
}
