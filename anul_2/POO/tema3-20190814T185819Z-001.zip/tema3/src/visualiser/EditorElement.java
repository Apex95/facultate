package visualiser;

public final class EditorElement {
	private final String type;
	
	public EditorElement(String type)
	{
		this.type = type;
	}

	// R: 'type' e marcat ca fiind final - se poate seta doar o singura data valoarea => fara setter
	public String getType() {
		return type;
	}

	// consider ca "ceva" == ceva; asta deoarece la unele teste se dau: input, div, card si
	// se cer "input", "div", "card" - ghilimelele alea nu cred ca trebuie sa fie p-acolo dupa parsare
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((type == null) ? 0 : type.replace("\"", "").hashCode());
		return result;
	}

	// la fel si aici
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EditorElement other = (EditorElement) obj;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.replace("\"", "").equals(other.type.replace("\"", "")))
			return false;
		return true;
	}
}
