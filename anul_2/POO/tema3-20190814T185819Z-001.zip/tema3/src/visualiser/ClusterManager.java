package visualiser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class ClusterManager {

	private static ClusterManager instance = null;
	
	private ClusterManager(int window) {
		ClusterManager.window = window; 
	}
	
	public static ClusterManager getInstance()
	{
		if (instance == null)
			return instance = new ClusterManager(10);
		else
			return instance;
	}
	
	
	private static int window;
	
	public List<Cluster> cluster(List<UserEvent> userEvents) {
		List<UserEvent> _userEvents = new ArrayList<UserEvent>(userEvents);
		
		List<Cluster> clusters = new ArrayList<Cluster>();
		
		// considerand ca sunt deja sortate dupa timestamp
		for (int i = 0; i < _userEvents.size(); i++)
		{
			Cluster c = new Cluster(new ArrayList<UserEvent>(), 0, 0);
			c.addUserEvent(_userEvents.get(i));
			
			for (int j = i+1; j < _userEvents.size(); j++)
			{
				UserEvent currentEvent = _userEvents.get(j);
				
				if (currentEvent.getTimestamp() <= c.getEndTimeStamp()
					&& !Collections.disjoint(currentEvent.getPageArea().getPathInEditor(), c.getUserEvents().get(0).getPageArea().getPathInEditor()))
				{
					c.addUserEvent(currentEvent);
					_userEvents.remove(currentEvent);	
					
					j--;
				}
			}
			
			if (c.getUserEvents().size() > 1)
				clusters.add(c);
	
		}
		
		return clusters;
		
	}
	
	public static class Cluster
	{
		private List<UserEvent> userEvents;
		private int startTimestamp;
		private int endTimeStamp;

		public Cluster(List<UserEvent> userEvents, int start, int end)
		{
			this.userEvents = userEvents;
			this.setStartTimestamp(start);
			this.setEndTimeStamp(end);
		}
		
		public void addUserEvent(UserEvent e)
		{
			userEvents.add(e);
			this.endTimeStamp = e.getTimestamp() + window - 1;
			
			if (userEvents.size() == 1)
				startTimestamp = e.getTimestamp();
		}

		public int getStartTimestamp() {
			return startTimestamp;
		}

		public void setStartTimestamp(int startTimestamp) {
			this.startTimestamp = startTimestamp;
		}

		public int getEndTimeStamp() {
			return endTimeStamp;
		}

		public void setEndTimeStamp(int endTimeStamp) {
			this.endTimeStamp = endTimeStamp;
		}
		
		public List<UserEvent> getUserEvents() {
			return userEvents;
		}

		public void setUserEvents(List<UserEvent> userEvents) {
			this.userEvents = userEvents;
		}
		
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + endTimeStamp;
			result = prime * result + startTimestamp;
			result = prime * result + ((userEvents == null) ? 0 : userEvents.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Cluster other = (Cluster) obj;
			if (endTimeStamp != other.endTimeStamp)
				return false;
			if (startTimestamp != other.startTimestamp)
				return false;
			if (userEvents == null) {
				if (other.userEvents != null)
					return false;
			} else if (!userEvents.equals(other.userEvents))
				return false;
			return true;
		}
	}
	
}
