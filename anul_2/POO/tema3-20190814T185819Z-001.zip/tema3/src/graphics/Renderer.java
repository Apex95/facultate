package graphics;

import java.awt.AWTError;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;

import graphics.Point.Builder;

public final class Renderer extends JFrame {
	// TODO(5.2): Implementati clasa Renderer cu ajutorul Fluent Builder pattern.
	
	private List<Point> points;
	private int circleSize = 10;
	private Map<visualiser.Color, java.awt.Color> colorsMap;

	private Renderer() 
	{
		points = new ArrayList<Point>();
	}
	
	public void draw() {
		setVisible(true);
	}
	
	public void addPoint(int x, int y, visualiser.Color color) {
		// TODO(5.2): Adaugati listei curente de puncte ce trebuiesc desenate, un nou punct cu
		// dimensiunea si culoarea primite ca parametrii.
		Point p = Point.builder()
					.X(x)
					.Y(y)
					.color(color)
					.build();
		
		
		points.add(p);
		
	}
	
	@Override
	public void paint(Graphics g) {
		Shape circle;
		Graphics2D ga = (Graphics2D)g;
		
		for (Point p : points) {
			circle = new Ellipse2D.Float(p.getX(), p.getY(), circleSize, circleSize);
		  	ga.draw(circle);
		  	ga.setPaint(getColor(p));
		  	ga.fill(circle);
	
		}
	}
	
	private java.awt.Color getColor(Point p) 
	{
		return colorsMap.get(p.getColor());
	}
	
	
	public static Builder builder()
	{
		return new Renderer.Builder();
	}
	
	public static class Builder
	{
		private Renderer r = new Renderer();
		
		public Builder withColorsMap(Map<visualiser.Color, java.awt.Color> colorsMap)
		{
			r.colorsMap = colorsMap;
			return this;
		}
		
		public Builder withDefaultCloseOperation(int closeOperation)
		{
			r.setDefaultCloseOperation(closeOperation);
			return this;
		}
		
		public Builder withTitle(String title)
		{
			r.setTitle(title);
			return this;
		}
		
		public Builder withSize(int x, int y)
		{
			r.setSize(x, y);
			return this;
		}
		
		public Renderer build()
		{
			return r;
		}
	}
}
