package graphics;

import visualiser.Color;

public final class Point 
{
	// TODO(5.1): Implementati clasa Point cu ajutorul Fluent Builder Pattern.
	private int x;
	private int y;
	private visualiser.Color color;
	
	private Point()
	{
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public visualiser.Color getColor() {
		//System.out.println(color == null);
		return color;
	}

	public static Builder builder()
	{
		return new Point.Builder();
	}
	
	public static class Builder
	{
		private Point p = new Point();
		
		public Builder X(int x)
		{
			p.x = x;
			return this;
		}
		
		public Builder Y(int y)
		{
			p.y = y;
			return this;
		}
		
		public Builder color(Color color)
		{
			p.color = color;
			return this;
		}
		
		public Point build()
		{
			return p;
		}
	}
}
